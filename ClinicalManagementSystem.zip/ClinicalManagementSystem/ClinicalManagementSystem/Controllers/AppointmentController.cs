﻿using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Repository;
using ClinicalManagementSystem.Service;
using Microsoft.AspNetCore.Mvc;

namespace ClinicalManagementSystem.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly IDoctorService _doctorService;
        private readonly IMedicineRepository _medicineRepository;
        private readonly ITestRepository _testRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AppointmentController(
            IDoctorService doctorService,
            IMedicineRepository medicineRepository,
            ITestRepository testRepository,
            IHttpContextAccessor httpContextAccessor)
        {
            _doctorService = doctorService;
            _medicineRepository = medicineRepository;
            _testRepository = testRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [Route("Appointment/Consultation/{id}")]
        public async Task<IActionResult> Consultation(int id)
        {
            if (id <= 0)
            {
                return NotFound();
            }

            var doctorId = HttpContext.Session.GetInt32("DoctorId");
            if (!doctorId.HasValue)
            {
                TempData["ErrorMessage"] = "Doctor ID could not be retrieved.";
                return RedirectToAction("Index", "Home");
            }

            var staffId = await _doctorService.GetStaffIdByDoctorIdAsync(doctorId.Value);
            if (!staffId.HasValue)
            {
                TempData["ErrorMessage"] = "Staff ID could not be retrieved.";
                return RedirectToAction("Index", "Home");
            }

            // Fetch the list of medicines and tests to display
            var medicines = await _medicineRepository.GetAllMedicinesAsync();
            var tests = await _testRepository.GetAllTestsAsync();

            var model = new CreatePrescriptionViewModel
            {
                AppointmentId = id,
                CreatedBy = staffId.Value,
                CreatedDate = DateTime.Now,
                Medicines = medicines.Select(m => new MedicineViewModel
                {
                    Name = m.MedicineName,
                    Quantity = 0, // default value or set as needed
                    Dosage = "",
                    Duration = "",
                    Frequency = "",
                    IsMedicineStatus = false
                }).ToList(),
                Tests = tests.Select(t => new TestViewModel
                {
                    Name = t.TestName,
                    IsStatus = false // default value or set as needed
                }).ToList()
            };

            return View("CreatePrescription", model);
        }

        [HttpPost]
        [Route("Appointment/CreatePrescription")]
        public async Task<IActionResult> CreatePrescription([FromBody] CreatePrescriptionViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var doctorId = HttpContext.Session.GetInt32("DoctorId");
                    if (doctorId.HasValue)
                    {
                        var staffId = await _doctorService.GetStaffIdByDoctorIdAsync(doctorId.Value);
                        if (staffId.HasValue)
                        {
                            var prescription = new MainPrescription
                            {
                                AppointmentId = model.AppointmentId,
                                CreatedBy = staffId.Value,
                                CreatedDate = DateTime.Now,
                                Symptoms = model.Symptoms,
                                Diagnosis = model.Diagnosis,
                                TreatmentPlan = model.TreatmentPlan
                            };

                            // Insert the prescription into the database
                            await _doctorService.InsertPrescriptionAsync(prescription);

                            // Add selected medicines to the prescription
                            foreach (var medicine in model.Medicines)
                            {
                                var medicineId = await _medicineRepository.GetMedicineIdByNameAsync(medicine.Name);
                                if (medicineId.HasValue)
                                {
                                    await _medicineRepository.AddMedicinePrescriptionAsync(
                                        model.AppointmentId,
                                        medicineId.Value,
                                        medicine.Quantity,
                                        medicine.Dosage,
                                        medicine.Duration,
                                        medicine.Frequency,
                                        medicine.IsMedicineStatus,
                                        staffId.Value
                                    );
                                }
                            }

                            // Add selected tests to the prescription
                            foreach (var test in model.Tests)
                            {
                                var testId = await _testRepository.GetTestIdByNameAsync(test.Name);
                                if (testId.HasValue)
                                {
                                    await _testRepository.AddTestPrescriptionAsync(
                                        model.AppointmentId,
                                        test.Name, // Ensure you pass the correct test name
                                        "", // Placeholder for test result; you should adjust based on your actual implementation
                                        test.IsStatus,
                                        staffId.Value
                                    );
                                }
                            }

                            return Json(new { success = true, message = "Prescription created successfully." });
                        }
                        else
                        {
                            return Json(new { success = false, message = "Staff ID could not be retrieved." });
                        }
                    }
                    else
                    {
                        return Json(new { success = false, message = "Doctor ID could not be retrieved." });
                    }
                }
                catch (Exception ex)
                {
                    return Json(new { success = false, message = $"An error occurred: {ex.Message}" });
                }
            }
            else
            {
                return Json(new { success = false, message = "Please ensure all required fields are filled out correctly." });
            }
        }
    }
}
