﻿using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Service;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ClinicalManagementSystem.Controllers
{

    public class DoctorDashboardController : Controller
    {
        private readonly IDoctorService _doctorService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public DoctorDashboardController(IDoctorService doctorService, IHttpContextAccessor httpContextAccessor)
        {
            _doctorService = doctorService;
            _httpContextAccessor = httpContextAccessor;
        }

        // Action to display the list of appointments
        public async Task<IActionResult> Index()
        {
            // Retrieve appointments from session
            var appointmentsJson = HttpContext.Session.GetString("Appointments");
            var appointments = appointmentsJson != null
                ? JsonConvert.DeserializeObject<IEnumerable<Appointment>>(appointmentsJson)
                : new List<Appointment>();

            if (appointments != null && appointments.Any())
            {
                return View(appointments);
            }

            // Handle case where no appointments are available
            ViewData["ErrorMessage"] = "No appointments available.";
            return View(new List<Appointment>());
        }

        // Action to handle the consultation creation based on appointment ID
        [HttpGet]
        [Route("DoctorDashboard/Consultation/{id}")]
        public async Task<IActionResult> Consultation(int id)
        {
            if (id <= 0)
            {
                return NotFound();
            }

            // Retrieve DoctorId based on the current user
            var doctorId = await _doctorService.GetDoctorIdByRoleAndUsernameAsync("Doctor", User.Identity.Name);
            if (!doctorId.HasValue)
            {
                ViewData["ErrorMessage"] = "Doctor ID could not be retrieved.";
                return RedirectToAction("Index");
            }

            // Retrieve StaffId based on DoctorId
            var staffId = await _doctorService.GetStaffIdByDoctorIdAsync(doctorId.Value);
            if (!staffId.HasValue)
            {
                ViewData["ErrorMessage"] = "Staff ID could not be retrieved.";
                return RedirectToAction("Index");
            }

            // Prepare model for creating a prescription
            var model = new MainPrescription
            {
                AppointmentId = id,
                CreatedBy = staffId.Value,
                CreatedDate = DateTime.Now
            };

            // Return view with model
            return View("CreatePrescription", model);
        }

        // Action to handle the creation of a prescription
        [HttpPost]
        [Route("DoctorDashboard/CreatePrescription")]
        public async Task<IActionResult> CreatePrescription(MainPrescription prescription)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Retrieve DoctorId based on the current user
                    var doctorId = await _doctorService.GetDoctorIdByRoleAndUsernameAsync("Doctor", User.Identity.Name);
                    if (doctorId.HasValue)
                    {
                        // Retrieve StaffId based on DoctorId
                        var staffId = await _doctorService.GetStaffIdByDoctorIdAsync(doctorId.Value);
                        if (staffId.HasValue)
                        {
                            // Set CreatedBy to the StaffId
                            prescription.CreatedBy = staffId.Value;
                            // Insert the prescription into the database
                            await _doctorService.InsertPrescriptionAsync(prescription);
                            ViewData["SuccessMessage"] = "Prescription created successfully.";
                        }
                        else
                        {
                            ViewData["ErrorMessage"] = "Staff ID could not be retrieved.";
                        }
                    }
                    else
                    {
                        ViewData["ErrorMessage"] = "Doctor ID could not be retrieved.";
                    }
                }
                catch (Exception ex)
                {
                    ViewData["ErrorMessage"] = $"An error occurred: {ex.Message}";
                }
            }
            else
            {
                ViewData["ErrorMessage"] = "Please ensure all required fields are filled out correctly.";
            }

            // Redirect back to the Index view
            return RedirectToAction("Index");
        }
    }
}
