using ClinicalManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ClinicalManagementSystem.Repository;


namespace ClinicalManagementSystem.Controllers



 {
 public class HomeController : Controller
 {
     private readonly ILogger<HomeController> _logger;

     public HomeController(ILogger<HomeController> logger)
     {
         _logger = logger;
     }

     public IActionResult Index()
     {
         return View();
     }

     public IActionResult Privacy()
     {
         return View();
     }

     [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
     public IActionResult Error()
     {
         return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
     }
 }
}
/*
{ 
    public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IAdminRepository _adminRepository;

    public HomeController(ILogger<HomeController> logger, IAdminRepository adminRepository)
    {
        _logger = logger;
        _adminRepository = adminRepository;
    }

    public IActionResult Index()
    {
        return View();
    }
    // POST: Home/Index (for login)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Index(Login login)
    {
        try
        {



            int roleId = _adminRepository.UserCredentials(login);
            TempData["Message"] = "Welcome, " + login.Username;


            switch (roleId)
            {
                case 1:
                    return RedirectToAction("Index", "Admin");
                case 2:
                    return RedirectToAction("Index", "Reception");
                case 3:
                    return RedirectToAction("Index", "Doctor");
                case 4:
                    return RedirectToAction("Index", "Pharmacist");
                case 5:
                    return RedirectToAction("Index", "LabTechnician");
                default:
                    // Invalid roleId or failed authentication
                    Console.WriteLine("Invalid username or password.");
                    return View(login);
            }
        }

        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }


        // Return the view with error messages
        return View(login);
    }


    public IActionResult Logout()
    {

        return View();



    }



    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }



 }
}
*/