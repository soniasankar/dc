﻿using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Service;
using Microsoft.AspNetCore.Mvc;

namespace ClinicalManagementSystem.Controllers
{
    public class PrescriptionController : Controller
    {
        private readonly IDoctorService _doctorService;

        public PrescriptionController(IDoctorService doctorService)
        {
            _doctorService = doctorService;
        }

        // GET: /Prescription/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Prescription/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Symptoms,Diagnosis,TreatmentPlan,AppointmentId,CreatedDate,CreatedBy")] MainPrescription prescription)
        {
            if (ModelState.IsValid)
            {
                await _doctorService.InsertPrescriptionAsync(prescription);
                return RedirectToAction("Index", "Appointment"); // Redirect to appointment index or another appropriate action
            }
            return View(prescription);
        }

        // POST: /Prescription/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            // Implement deletion logic if applicable. For this example, deletion logic is not specified in the service.
            // Assuming you might need to implement it in the service/repository if required.

            // Example: await _doctorService.DeletePrescriptionAsync(id); // You need to implement DeletePrescriptionAsync in your service.

            return RedirectToAction("Index", "Appointment"); // Redirect to appointment index or another appropriate action
        }
    }
}
