﻿namespace ClinicalManagementSystem.Models
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public string TokenNumber { get; set; }
        public bool ConsultationStatus { get; set; }
        public string PatientName {  get; set; } 
    }
}
