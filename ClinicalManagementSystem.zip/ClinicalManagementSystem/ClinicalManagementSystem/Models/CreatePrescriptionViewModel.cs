﻿using System.ComponentModel.DataAnnotations;

namespace ClinicalManagementSystem.Models
{
    public class CreatePrescriptionViewModel
    {
        [Required]
        public string Symptoms { get; set; }

        [Required]
        public string Diagnosis { get; set; }

        [Required]
        public string TreatmentPlan { get; set; }

        [Required]
        public int AppointmentId { get; set; }

        [Required]
        public int CreatedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        public List<MedicineViewModel> Medicines { get; set; } = new List<MedicineViewModel>();
        public List<TestViewModel> Tests { get; set; } = new List<TestViewModel>(); // Ensure this property is present
    }
}

