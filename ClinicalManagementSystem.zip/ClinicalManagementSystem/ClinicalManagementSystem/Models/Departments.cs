﻿namespace ClinicalManagementSystem.Models
{
    public class Departments
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }

    }
}
