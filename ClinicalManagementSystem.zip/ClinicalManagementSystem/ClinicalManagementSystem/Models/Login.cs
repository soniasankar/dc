﻿using ClinicalManagementSystem.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ClinicalManagementSystem.Models
{

    public class Login
    {
        [Key]
        public int LoginId { get; set; }

        [Required]
        public int StaffId { get; set; }

        [Required]
        [StringLength(50)]

        public string Username { get; set; }

        [Required]
        [StringLength(255)]
        public string Password { get; set; }

        [ForeignKey("StaffId")]
        public virtual Staff Staff { get; set; }
    }
}

