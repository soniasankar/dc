﻿namespace ClinicalManagementSystem.Models
{
    public class MedicineBill
    {
        public int MedicineBillId { get; set; }
        public int AppointmentId { get; set; }
        public decimal GrandTotalAmount { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }

        // Navigation properties
        public Appointment Appointment { get; set; }
        public Staff CreatedByStaff { get; set; }
    }
}
