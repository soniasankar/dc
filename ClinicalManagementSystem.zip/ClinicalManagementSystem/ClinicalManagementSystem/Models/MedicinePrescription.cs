﻿namespace ClinicalManagementSystem.Models
{
    public class MedicinePrescription
    {
        public int MedicinePrescriptionId { get; set; }
        public int AppointmentId { get; set; }
        public int Quantity { get; set; }
        public string Dosage { get; set; }
        public string Duration { get; set; }
        public string Frequency { get; set; }
        public bool IsMedicineStatus { get; set; } = false;
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public int CreatedBy { get; set; }

        // Navigation property
        public Appointment Appointment { get; set; }
        public Staff CreatedByStaff { get; set; }
    }
}
