﻿namespace ClinicalManagementSystem.Models
{
public class MedicinePrescriptionViewModel
        {
            public int Quantity { get; set; }
            public int Dosage { get; set; }
            public int Duration { get; set; }
            public int Frequency { get; set; }
            public DateTime CreatedDate { get; set; }
            public string CreatedBy { get; set; }
            public string MedicineName { get; set; }
        }

    }
