﻿namespace ClinicalManagementSystem.Models
{
    public class Specializations
    {
        public int SpecializationId { get; set; }
        public string SpecializationName { get; set; }
    }
}
