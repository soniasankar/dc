﻿namespace ClinicalManagementSystem.Models
{
    public class TestInfo
    {
        public int TestId { get; set; }
        public string TestName { get; set; }
        public string TestType { get; set; }
        public string Category { get; set; }
        public decimal Amount { get; set; }
        public string ReferenceMaxRange { get; set; }
        public string SampleRequired { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
    }
}
