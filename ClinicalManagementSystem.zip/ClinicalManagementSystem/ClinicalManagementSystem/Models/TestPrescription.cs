﻿namespace ClinicalManagementSystem.Models
{
    public class TestPrescription
    {
        public int TestPrescriptionId { get; set; }
        public int AppointmentId { get; set; }
        public int TestId { get; set; }
        public string TestResult { get; set; }
        public bool IsStatus { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
    }
}
