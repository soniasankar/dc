﻿using System.ComponentModel.DataAnnotations;

namespace ClinicalManagementSystem.Models
{
  
        public class TestViewModel
        {
            [Required]
            public string Name { get; set; }

            [Required]
            public bool IsStatus { get; set; }
        }
    }


