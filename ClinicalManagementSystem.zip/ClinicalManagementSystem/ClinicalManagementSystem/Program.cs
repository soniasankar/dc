using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Repository;
using ClinicalManagementSystem.Service;

namespace ClinicalManagementSystem
{/*
    +
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var connectionString = builder.Configuration.GetConnectionString("ConnectionMVCWin");
            builder.Services.AddSingleton(connectionString);
            builder.Services.AddScoped<IDoctorRepository, DoctorRepositoryImp>();
            builder.Services.AddScoped<IDoctorService, DoctorServiceImp>();
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=DoctorDashboard}/{action=AppointmentList}/{id?}");

            app.Run();
        }
    }
}

    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // Register repositories and services
            builder.Services.AddScoped<IDoctorRepository, DoctorRepositoryImp>();
            builder.Services.AddScoped<IDoctorService, DoctorServiceImp>();
            builder.Services.AddScoped<ILoginRepository, LoginRepositoryImp>();
            builder.Services.AddScoped<ILoginService, LoginServiceImp>();

            // Register the MedicineRepository with the DI container
            builder.Services.AddScoped<IMedicineRepository, MedicineRepository>();
            builder.Services.AddScoped<ITestRepository, TestRepository>();

            // Register IHttpContextAccessor for accessing HttpContext in services
            builder.Services.AddHttpContextAccessor();

            // Add session services
            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
                options.Cookie.HttpOnly = true; // Ensure cookies are only accessible via HTTP
                options.Cookie.IsEssential = true; // Make the session cookie essential for the application
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                // Configure error handling for production
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            else
            {
                // Configure error handling for development
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection(); // Redirect HTTP requests to HTTPS
            app.UseStaticFiles(); // Serve static files (e.g., CSS, JavaScript)

            app.UseRouting(); // Route requests to controllers

            app.UseSession(); // Enable session state management

            app.UseAuthentication(); // Enable authentication middleware (if using authentication)
            app.UseAuthorization(); // Enable authorization middleware

            // Configure default route
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Login}/{action=Index}/{id?}");

            // Optionally, you can map Razor Pages if using them
            // app.MapRazorPages();

            app.Run();
        }
    }
}
*/
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // Register repositories and services
            builder.Services.AddScoped<IDoctorRepository, DoctorRepositoryImp>();
            builder.Services.AddScoped<IDoctorService, DoctorServiceImp>();
            builder.Services.AddScoped<ILoginRepository, LoginRepositoryImp>();
            builder.Services.AddScoped<ILoginService, LoginServiceImp>();
            builder.Services.AddScoped<IMedicineRepository, MedicineRepository>();
            builder.Services.AddScoped<ITestRepository, TestRepository>();
            builder.Services.AddScoped<IAppointmentRepository, AppointmentRepository>();
         //   builder.Services.AddScoped<IAdminRepository, AdminRepositoryImpl>();
           // builder.Services.AddScoped<IAdminService, AdminServiceImpl>();

            // Register IHttpContextAccessor for accessing HttpContext in services
            builder.Services.AddHttpContextAccessor();

            // Add session services
            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
                options.Cookie.HttpOnly = true; // Ensure cookies are only accessible via HTTP
                options.Cookie.IsEssential = true; // Make the session cookie essential for the application
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                // Configure error handling for production
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            else
            {
                // Configure error handling for development
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection(); // Redirect HTTP requests to HTTPS
            app.UseStaticFiles(); // Serve static files (e.g., CSS, JavaScript)

            app.UseRouting(); // Route requests to controllers

            app.UseSession(); // Enable session state management

            app.UseAuthentication(); // Enable authentication middleware (if using authentication)
            app.UseAuthorization(); // Enable authorization middleware

            // Configure default route
            app.MapControllerRoute(
                name: "default",
                    pattern: "{controller=Login}/{action=Index}/{id?}");
                   // pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
