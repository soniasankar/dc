﻿using System.Data.SqlClient;
using System.Data;
using ClinicalManagementSystem.Models;

namespace ClinicalManagementSystem.Repository
{
    public class AppointmentRepository : IAppointmentRepository
    {
        private readonly string _connectionString;

        public AppointmentRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task<AppointmentDetailsViewModel> GetAppointmentDetailsAsync(int appointmentId)
        {
            var details = new AppointmentDetailsViewModel
            {
                Medicines = new List<MedicinePrescriptionViewModel>(),
                Tests = new List<TestPrescriptionViewModel>()
            };

            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand("GetAppointmentDetails", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AppointmentId", appointmentId);

                    connection.Open();

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        // Read main prescription details
                        if (await reader.ReadAsync())
                        {
                            details.Symptoms = reader["Symptoms"].ToString();
                            details.Diagnosis = reader["Diagnosis"].ToString();
                            details.TreatmentPlan = reader["TreatmentPlan"].ToString();
                            details.CreatedDate = reader["CreatedDate"] != DBNull.Value ? (DateTime)reader["CreatedDate"] : DateTime.MinValue;
                            details.CreatedBy = reader["CreatedBy"].ToString();
                        }

                        // Read medicine prescription details
                        reader.NextResult();
                        while (await reader.ReadAsync())
                        {
                            details.Medicines.Add(new MedicinePrescriptionViewModel
                            {
                                Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToInt32(reader["Quantity"]) : 0,
                                Dosage = reader["Dosage"] != DBNull.Value ? Convert.ToInt32(reader["Dosage"]) : 0,
                                Duration = reader["Duration"] != DBNull.Value ? Convert.ToInt32(reader["Duration"]) : 0,
                                Frequency = reader["Frequency"] != DBNull.Value ? Convert.ToInt32(reader["Frequency"]) : 0,
                                CreatedDate = reader["CreatedDate"] != DBNull.Value ? (DateTime)reader["CreatedDate"] : DateTime.MinValue,
                                CreatedBy = reader["CreatedBy"].ToString(),
                                MedicineName = reader["MedicineName"].ToString()
                            });
                        }

                        // Read test prescription details
                        reader.NextResult();
                        while (await reader.ReadAsync())
                        {
                            details.Tests.Add(new TestPrescriptionViewModel
                            {
                                TestResult = reader["TestResult"].ToString(),
                                CreatedDate = reader["CreatedDate"] != DBNull.Value ? (DateTime)reader["CreatedDate"] : DateTime.MinValue,
                                CreatedBy = reader["CreatedBy"].ToString(),
                                TestName = reader["TestName"].ToString()
                            });
                        }
                    }
                }
            }

            return details;
        }

       
    }
}
