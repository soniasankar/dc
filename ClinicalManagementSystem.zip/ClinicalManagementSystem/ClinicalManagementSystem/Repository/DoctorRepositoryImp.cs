﻿using ClinicalManagementSystem.Models;
using System.Data.SqlClient;
using System.Data;

namespace ClinicalManagementSystem.Repository
{
    public class DoctorRepositoryImp : IDoctorRepository
    {
        private readonly string connectionString;

        public DoctorRepositoryImp(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password)
        {
            const string storedProcedure = "sp_GetRoleByUsernamePassword";
            Roles role = null;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand(storedProcedure, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@Username", SqlDbType.NVarChar, 255)).Value = username ?? (object)DBNull.Value;
                        command.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar, 255)).Value = password ?? (object)DBNull.Value;

                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                role = new Roles
                                {
                                    RoleId = reader.GetInt32(reader.GetOrdinal("RoleId")),
                                    RoleName = reader.GetString(reader.GetOrdinal("RoleName")),
                                    IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive"))
                                };
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while retrieving role details from the database.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }

            return role;
        }

        public async Task<int?> GetDoctorIdByRoleAndUsernameAsync(string roleName, string username)
        {
            const string storedProcedure = "sp_GetDoctorIdByRoleAndUsername";
            int? doctorId = null;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand(storedProcedure, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@RoleName", SqlDbType.NVarChar, 100)).Value = roleName ?? (object)DBNull.Value;
                        command.Parameters.Add(new SqlParameter("@Username", SqlDbType.NVarChar, 100)).Value = username ?? (object)DBNull.Value;

                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                doctorId = reader.GetInt32(reader.GetOrdinal("DoctorId"));
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while retrieving doctor ID from the database.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }

            return doctorId;
        }

        public async Task<IEnumerable<Appointment>> GetAppointmentsByDoctorIdAsync(int doctorId)
        {
            var appointments = new List<Appointment>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("sp_GetAppointmentsByDoctorId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@DoctorId", SqlDbType.Int)).Value = doctorId;

                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var appointment = new Appointment
                                {
                                    AppointmentId = reader.GetInt32(reader.GetOrdinal("AppointmentId")),
                                    AppointmentDate = reader.GetDateTime(reader.GetOrdinal("AppointmentDate")),
                                    PatientName = reader.GetString(reader.GetOrdinal("PatientName")),
                                    TokenNumber = reader.GetString(reader.GetOrdinal("TokenNumber")),
                                };
                                appointments.Add(appointment);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while retrieving appointments from the database.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }

            return appointments;
        }

        public async Task<int?> GetStaffIdByDoctorIdAsync(int doctorId)
        {
            const string storedProcedure = "sp_GetStaffIdByDoctorId";
            int? staffId = null;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand(storedProcedure, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@DoctorId", SqlDbType.Int)).Value = doctorId;

                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                staffId = reader.GetInt32(reader.GetOrdinal("StaffId"));
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while retrieving staff ID from the database.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }

            return staffId;
        }

        public async Task InsertPrescriptionAsync(MainPrescription prescription)
        {
            const string storedProcedure = "sp_InsertMainPrescription";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand(storedProcedure, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add(new SqlParameter("@Symptoms", SqlDbType.NVarChar, 1000)).Value = prescription.Symptoms ?? (object)DBNull.Value;
                        command.Parameters.Add(new SqlParameter("@Diagnosis", SqlDbType.NVarChar, 1000)).Value = prescription.Diagnosis ?? (object)DBNull.Value;
                        command.Parameters.Add(new SqlParameter("@TreatmentPlan", SqlDbType.NVarChar, 1000)).Value = prescription.TreatmentPlan ?? (object)DBNull.Value;
                        command.Parameters.Add(new SqlParameter("@AppointmentId", SqlDbType.Int)).Value = prescription.AppointmentId;
                        command.Parameters.Add(new SqlParameter("@CreatedDate", SqlDbType.DateTime)).Value = prescription.CreatedDate;
                        command.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int)).Value = prescription.CreatedBy;

                        await connection.OpenAsync();
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("An error occurred while inserting the prescription into the database.", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }
        }

        //public Task<IEnumerable<Appointment>> GetAppointmentsAsync()
        //{
        //    throw new NotImplementedException();
        //}
    }
}
