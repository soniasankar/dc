﻿using ClinicalManagementSystem.Models;

namespace ClinicalManagementSystem.Repository
{
    
    public interface IAppointmentRepository
    {
        Task<AppointmentDetailsViewModel> GetAppointmentDetailsAsync(int appointmentId);
    }
}
