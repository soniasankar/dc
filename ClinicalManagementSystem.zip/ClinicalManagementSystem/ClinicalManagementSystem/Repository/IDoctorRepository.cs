﻿using ClinicalManagementSystem.Models;
using System.Data;

namespace ClinicalManagementSystem.Repository
{
  
        public interface IDoctorRepository
        {
            //IEnumerable<Appointment> GetAppointments();
            Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password);
            Task<int?> GetDoctorIdByRoleAndUsernameAsync(string roleName, string username);
            Task<IEnumerable<Appointment>> GetAppointmentsByDoctorIdAsync(int doctorId);
            Task<int?> GetStaffIdByDoctorIdAsync(int doctorId);
            Task InsertPrescriptionAsync(MainPrescription prescription);
          //   Task<IEnumerable<Appointment>> GetAppointmentsAsync();
    }

    }
