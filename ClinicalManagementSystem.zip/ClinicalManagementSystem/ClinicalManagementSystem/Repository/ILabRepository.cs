﻿namespace ClinicalManagementSystem.Repository
{
    public interface ILabRepository
    {
    }
}
