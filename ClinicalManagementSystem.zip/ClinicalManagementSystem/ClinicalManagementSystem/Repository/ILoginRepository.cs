﻿
using ClinicalManagementSystem.Models;

public interface ILoginRepository
{
    Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password);
}

