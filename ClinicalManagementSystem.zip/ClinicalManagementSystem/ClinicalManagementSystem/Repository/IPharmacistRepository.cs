﻿namespace ClinicalManagementSystem.Repository
{
    public interface IPharmacistRepository
    {
    }
}
