﻿using ClinicalManagementSystem.Models;

namespace ClinicalManagementSystem.Repository
{
   

        public interface ITestRepository
        {
            /// <summary>
            /// Adds a test prescription to the database.
            /// </summary>
            /// <param name="appointmentId">The ID of the appointment.</param>
            /// <param name="testName">The name of the test.</param>
            /// <param name="testResult">The result of the test.</param>
            /// <param name="isStatus">The status indicating if the test is active.</param>
            /// <param name="createdBy">The ID of the staff who created the prescription.</param>
            /// <returns>A task representing the asynchronous operation.</returns>
            Task AddTestPrescriptionAsync(int appointmentId, string testName, string testResult, bool isStatus, int createdBy);

            /// <summary>
            /// Retrieves all tests from the database.
            /// </summary>
            /// <returns>A task that represents the asynchronous operation, with a result of a collection of <see cref="TestInfo"/>.</returns>
            Task<IEnumerable<TestInfo>> GetAllTestsAsync();

            /// <summary>
            /// Retrieves the test ID for a given test name.
            /// </summary>
            /// <param name="testName">The name of the test.</param>
            /// <returns>A task that represents the asynchronous operation, with a result of the test ID or null if not found.</returns>
            Task<int?> GetTestIdByNameAsync(string testName);
        }
    }




