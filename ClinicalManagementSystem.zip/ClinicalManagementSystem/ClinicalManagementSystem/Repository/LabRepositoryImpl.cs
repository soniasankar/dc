﻿using ClinicalManagementSystem.Models;

namespace ClinicalManagementSystem.Repository
{
    public class LabRepositoryImpl
    {
      
        }
    }

