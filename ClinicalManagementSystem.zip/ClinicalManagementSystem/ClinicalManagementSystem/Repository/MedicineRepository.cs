﻿using ClinicalManagementSystem.Models;
using System.Data.SqlClient;
using System.Data;

namespace ClinicalManagementSystem.Repository
{
    public class MedicineRepository : IMedicineRepository
    {
        private readonly string _connectionString;

        public MedicineRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task<int?> GetMedicineIdByNameAsync(string medicineName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("sp_GetMedicineIdByName", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MedicineName", medicineName);

                    var result = await command.ExecuteScalarAsync();
                    return result != null ? (int?)result : null;
                }
            }
        }

        public async Task AddMedicinePrescriptionAsync(int appointmentId, int medicineId, int quantity, string dosage, string duration, string frequency, bool isMedicineStatus, int createdBy)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("sp_AddMedicinePrescription", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AppointmentId", appointmentId);
                    command.Parameters.AddWithValue("@MedicineId", medicineId);
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@Dosage", dosage);
                    command.Parameters.AddWithValue("@Duration", duration);
                    command.Parameters.AddWithValue("@Frequency", frequency);
                    command.Parameters.AddWithValue("@IsMedicineStatus", isMedicineStatus);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy);

                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<IEnumerable<MedicineInfo>> GetAllMedicinesAsync()
        {
            var medicines = new List<MedicineInfo>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("sp_GetAllMedicines", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var medicine = new MedicineInfo
                            {
                                MedicineId = reader.GetInt32(reader.GetOrdinal("MedicineId")),
                                MedicineName = reader.GetString(reader.GetOrdinal("MedicineName")),
                                GenericName = reader.GetString(reader.GetOrdinal("GenericName")),
                                ManufacturingDate = reader.GetDateTime(reader.GetOrdinal("ManufacturingDate")),
                                ExpiryDate = reader.GetDateTime(reader.GetOrdinal("ExpiryDate")),
                                Category = reader.GetString(reader.GetOrdinal("Category")),
                                PricePerUnit = reader.GetDecimal(reader.GetOrdinal("PricePerUnit")),
                                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                                CreatedBy = reader.GetInt32(reader.GetOrdinal("CreatedBy"))
                            };

                            medicines.Add(medicine);
                        }
                    }
                }
            }

            return medicines;
        }
    }
}

