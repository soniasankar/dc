﻿namespace ClinicalManagementSystem.Repository
{
    public class PharmacistRepositoryImpl
    {
    }
}
