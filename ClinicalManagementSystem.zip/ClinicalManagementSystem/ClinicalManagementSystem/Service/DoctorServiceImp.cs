﻿using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Repository;
using System.Data;

namespace ClinicalManagementSystem.Service
{


    public class DoctorServiceImp : IDoctorService
    {
        private readonly IDoctorRepository _doctorRepository;

        public DoctorServiceImp(IDoctorRepository doctorRepository)
        {
            _doctorRepository = doctorRepository;
        }

        public async Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password)
        {
            return await _doctorRepository.GetRoleByUsernamePasswordAsync(username, password);
        }

        public async Task<int?> GetDoctorIdByRoleAndUsernameAsync(string roleName, string username)
        {
            return await _doctorRepository.GetDoctorIdByRoleAndUsernameAsync(roleName, username);
        }

        public async Task<IEnumerable<Appointment>> GetAppointmentsByDoctorIdAsync(int doctorId)
        {
            return await _doctorRepository.GetAppointmentsByDoctorIdAsync(doctorId);
        }

        public async Task<int?> GetStaffIdByDoctorIdAsync(int doctorId)
        {
            return await _doctorRepository.GetStaffIdByDoctorIdAsync(doctorId);
        }

        public async Task InsertPrescriptionAsync(MainPrescription prescription)
        {
            await _doctorRepository.InsertPrescriptionAsync(prescription);
        }
    }
}
