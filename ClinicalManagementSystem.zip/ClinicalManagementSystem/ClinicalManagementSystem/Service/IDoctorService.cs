﻿using ClinicalManagementSystem.Models;
using System.Data;

namespace ClinicalManagementSystem.Service
{
  
        public interface IDoctorService
        {
        Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password);
        Task<int?> GetDoctorIdByRoleAndUsernameAsync(string roleName, string username);
        Task<IEnumerable<Appointment>> GetAppointmentsByDoctorIdAsync(int doctorId);
        Task<int?> GetStaffIdByDoctorIdAsync(int doctorId);
        Task InsertPrescriptionAsync(MainPrescription prescription);
        //IEnumerable<Appointment> GetAppointments();
    }
    }

