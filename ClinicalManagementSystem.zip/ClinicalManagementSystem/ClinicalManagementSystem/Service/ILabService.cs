﻿namespace ClinicalManagementSystem.Service
{
    public interface ILabService
    {
    }
}

