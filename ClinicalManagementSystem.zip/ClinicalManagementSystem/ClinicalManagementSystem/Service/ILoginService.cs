﻿using ClinicalManagementSystem.Models;

namespace ClinicalManagementSystem.Service
{
   
        public interface ILoginService
        {
            Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password);
        }
    }


