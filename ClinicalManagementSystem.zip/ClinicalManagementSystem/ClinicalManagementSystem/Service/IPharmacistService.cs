﻿namespace ClinicalManagementSystem.Service
{
    public interface IPharmacistService
    {
    }
}
