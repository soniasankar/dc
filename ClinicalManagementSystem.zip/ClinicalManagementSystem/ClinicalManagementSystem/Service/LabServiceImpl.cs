﻿namespace ClinicalManagementSystem.Service
{
    public class LabServiceImpl
    {
    }
}
