﻿using ClinicalManagementSystem.Models;
using ClinicalManagementSystem.Repository;

namespace ClinicalManagementSystem.Service
{
   
        public class LoginServiceImp : ILoginService
        {
            private readonly ILoginRepository _loginRepository;

            public LoginServiceImp(ILoginRepository loginRepository)
            {
                _loginRepository = loginRepository;
            }
            public async Task<Roles> GetRoleByUsernamePasswordAsync(string username, string password)
            {
                var role = await _loginRepository.GetRoleByUsernamePasswordAsync(username, password);
                return role;
            }
        }
    }

