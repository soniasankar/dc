﻿using ClinicalManagementSystem.Repository;

namespace ClinicalManagementSystem.Service
{
    public class MedicineService : IMedicineService
    {
        private readonly IMedicineRepository _medicineRepository;

        public MedicineService(IMedicineRepository medicineRepository)
        {
            _medicineRepository = medicineRepository;
        }
        public async Task AddMedicinePrescriptionAsync(int appointmentId, int medicineId, int quantity, string dosage, string duration, string frequency, bool isMedicineStatus, int createdBy)
        {
            await _medicineRepository.AddMedicinePrescriptionAsync(appointmentId, medicineId, quantity, dosage, duration, frequency, isMedicineStatus, createdBy);
        }

        public async Task<int?> GetMedicineIdByNameAsync(string medicineName)
        {
            return await _medicineRepository.GetMedicineIdByNameAsync(medicineName);
        }
    }
}

