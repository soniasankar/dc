﻿namespace ClinicalManagementSystem.Service
{
    public class PharmacistServiceImpl
    {
    }
}
